// src/users/user.entity.ts
export class User {
  id: number;
  password: string;
  email: string;
  firstName: string;
  lastName: string;
  username: string;
}