import { Injectable, ConflictException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Document } from 'mongoose';
import { User } from './schemas/user.schema';
import { House } from '../house/schemas/house.schema'; // Assurez-vous que le chemin d'accès est correct
import { CreateUserDto } from './dto/create-user.dto'; // Importez CreateUserDto

// Create user document type
type UserDocument = User & Document;
type HouseDocument = House & Document;

@Injectable()
export class UsersService {
  constructor(
    @InjectModel('User') private userModel: Model<UserDocument>,
    @InjectModel('House') private houseModel: Model<HouseDocument> 
  ) {}

  async create(createUserDto: CreateUserDto): Promise<User> {
    const existingUser = await this.userModel.findOne({ email: createUserDto.email });
    if (existingUser) {
      throw new ConflictException('Email already in use');
    }

    const newUser = new this.userModel(createUserDto);

    // Créer une maison par défaut et l'associer à l'utilisateur
    const defaultHouse = new this.houseModel({ name: 'Default House', users: [newUser._id] });
    await defaultHouse.save();

    newUser.houses = [defaultHouse._id];

    return newUser.save();
  }
  async findOne(email: string): Promise<User | undefined> {
    return this.userModel.findOne({ email }).exec();
  }
}
