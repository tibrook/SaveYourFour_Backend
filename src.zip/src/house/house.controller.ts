import { Controller, Get, Post, Put, Delete, Body,Param } from '@nestjs/common';
import {HouseService} from './house.service';
import {CreateInventoryCategoryDto,UpdateInventoryCategoryDto } from './inventory.dto'

@Controller('house')
export class HouseController {
  constructor(private readonly houseService: HouseService) {}

  @Get('/:houseId/categories')
  getAllInventoryCategories(@Param('houseId') houseId: string) {
    return this.houseService.getAllInventoryCategories(houseId);
  }

  @Post('/:houseId/categories')
  addInventoryCategory(@Param('houseId') houseId: string, @Body() categoryData: CreateInventoryCategoryDto) {
    return this.houseService.addInventoryCategory(houseId, categoryData.name, categoryData.description);
  }

  @Put('/:houseId/categories/:id')
  updateInventoryCategory(@Param('houseId') houseId: string, @Param('id') id: string, @Body() categoryData: UpdateInventoryCategoryDto) {
    return this.houseService.updateInventoryCategory(houseId, id, categoryData.name, categoryData.description);
  }

  @Delete('/:houseId/categories/:id')
  deleteInventoryCategory(@Param('houseId') houseId: string, @Param('id') id: string) {
    return this.houseService.deleteInventoryCategory(houseId, id);
  }
}